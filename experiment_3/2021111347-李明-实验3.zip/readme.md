1. 直接单击a.bat即可编译运行
2. test.io是测试输入，test.out是测试输出。testfile.txt为选做7比较算法优化前后效率的自动生成的测试用例。
