1. test data and result are in the laboratory report.
2. Please ues GBK to display the annotations correctly.
